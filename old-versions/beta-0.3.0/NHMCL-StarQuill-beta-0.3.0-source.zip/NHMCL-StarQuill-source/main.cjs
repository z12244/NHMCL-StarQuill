const {app,BrowserWindow,ipcMain,dialog,shell,net}=require('electron');
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {Game,inspectJava}=require('./game.cjs');
const {layout,scan,writeJSON,migrateLegacy}=require('./storage.cjs');
const {validate,runtimePath,redact}=require('./core.cjs');
let win,child,busy=false,controller,settings,logs=[],closing=false;
let state={phase:'idle',text:'准备就绪',percent:0};
const home=()=>app.getPath('userData');
const portable=()=>process.env.PORTABLE_EXECUTABLE_DIR||(app.isPackaged?path.dirname(process.execPath):__dirname);
const defaults=()=>({name:'Player',memory:Math.min(4,Math.max(1,Math.floor(os.totalmem()/1024**3/2))),java:'',selected:'1.21.1',snapshots:false,root:path.join(portable(),'.minecraft'),isolate:true,source:'auto',concurrency:16});
const bundled=()=>runtimePath(process.resourcesPath,__dirname,app.isPackaged);
function send(event,data){if(win&&!win.isDestroyed())win.webContents.send(event,data);}
function status(phase,text,percent=0){state={phase,text,percent:Number.isFinite(percent)?Math.min(100,Math.max(0,percent)):0};send('state',state);}
function log(text){const line='['+new Date().toLocaleTimeString('zh-CN')+'] '+redact(text);logs.push(line);if(logs.length>1000)logs.shift();send('log',line);}
async function persist(){await writeJSON(path.join(home(),'settings.json'),settings);}
async function local(){return scan(settings.root);}
function requireIdle(){if(busy)throw Error('请等待当前任务结束后再修改游戏目录或设置');}
function engine(extra={}){return new Game({...settings,java:settings.java||bundled(),version:settings.selected,onLog:log,fetcher:(...args)=>net.fetch(...args),...extra});}
app.whenReady().then(async()=>{
  await fs.mkdir(home(),{recursive:true});settings=defaults();try{settings={...settings,...JSON.parse(await fs.readFile(path.join(home(),'settings.json'),'utf8'))};}catch{}
  win=new BrowserWindow({width:1260,height:850,minWidth:980,minHeight:720,backgroundColor:'#101915',title:'NHMCL-StarQuill · 星翎启动器',icon:path.join(__dirname,'assets','icon.png'),autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',e=>e.preventDefault());
  win.on('close',e=>{if(busy&&!closing){e.preventDefault();dialog.showMessageBox(win,{type:'question',message:'当前任务尚未结束，是否关闭？',detail:'下载将保留已完成文件与续传数据；运行中的游戏将结束。',buttons:['继续运行','关闭并结束任务'],defaultId:0,cancelId:0}).then(({response})=>{if(response===1){closing=true;controller?.abort();child?.kill();app.exit(0);}});}});
  win.on('focus',()=>{if(settings&&!busy)local().then(items=>send('instances-changed',items)).catch(()=>{});});
  await win.loadFile('index.html');
});
app.on('window-all-closed',()=>app.quit());
ipcMain.handle('boot',async()=>({settings,instances:await local(),bundledJava:await inspectJava(bundled()).catch(()=>null),totalMemory:Math.round(os.totalmem()/1024**3),state,version:app.getVersion()}));
ipcMain.handle('versions',async()=>engine().manifest());
ipcMain.handle('instances',()=>local());
ipcMain.handle('settings',async(_,o)=>{requireIdle();validate({version:o.selected||'1.21.1',name:o.name,memory:o.memory});
  if(typeof o.java!=='string'||o.java.length>1024)throw Error('Java 路径无效');
  if(typeof o.root!=='string'||!path.isAbsolute(o.root))throw Error('请选择有效的 .minecraft 根目录');
  if(!['auto','bmclapi','official'].includes(o.source))throw Error('下载源无效');
  if(!Number.isInteger(o.concurrency)||o.concurrency<1||o.concurrency>32)throw Error('下载并发须为 1–32');
  await fs.mkdir(o.root,{recursive:true});await fs.access(o.root,require('node:fs').constants.W_OK);
  settings={name:o.name,memory:o.memory,java:o.java,selected:o.selected,snapshots:!!o.snapshots,root:path.resolve(o.root),isolate:o.isolate!==false,source:o.source,concurrency:o.concurrency};await persist();return {settings,instances:await local()};
});
ipcMain.handle('select-root',async()=>{requireIdle();const r=await dialog.showOpenDialog(win,{title:'选择已有 .minecraft 或启动器所在文件夹',defaultPath:settings.root,properties:['openDirectory','createDirectory']});if(r.canceled)return null;let root=r.filePaths[0];try{if((await fs.stat(path.join(root,'.minecraft'))).isDirectory())root=path.join(root,'.minecraft');}catch{}return {root,instances:await scan(root)};});
ipcMain.handle('migrate',async()=>{requireIdle();const r=await dialog.showOpenDialog(win,{title:'选择旧 Aster 的 instances 文件夹（复制导入，不删除原数据）',defaultPath:path.join(app.getPath('appData'),'aster-launcher','instances'),properties:['openDirectory']});if(r.canceled)return null;
  busy=true;status('preparing','正在复制旧版数据');try{const result=await migrateLegacy(r.filePaths[0],settings.root,text=>status('preparing',text));log(`迁移完成：${result.versions} 个版本，复制 ${result.copied} 个文件，跳过已有 ${result.skipped} 个文件`);if(result.conflicts.length)log('同名版本配置不同，未覆盖：'+result.conflicts.join('、'));send('instances-changed',await local());status('idle','迁移完成');return result;}catch(e){status('error',e.message);throw e;}finally{busy=false;}
});
ipcMain.handle('java',async()=>{const r=await dialog.showOpenDialog(win,{title:'选择 java.exe',properties:['openFile'],filters:[{name:'Java',extensions:['exe']}]});return r.canceled?null:inspectJava(r.filePaths[0]);});
ipcMain.handle('folder',async(_,id)=>{const p=id?layout(settings.root,id,settings.isolate).game:settings.root;await fs.mkdir(p,{recursive:true});const error=await shell.openPath(p);if(error)throw Error(error);});
ipcMain.handle('export-log',async()=>{const r=await dialog.showSaveDialog(win,{defaultPath:'NHMCL-StarQuill-log.txt',filters:[{name:'文本日志',extensions:['txt']}]});if(r.canceled)return false;await fs.writeFile(r.filePath,logs.join('\r\n'));return true;});
ipcMain.handle('stop',()=>{if(child){child.kill();return true;}if(controller){controller.abort();return true;}return false;});
ipcMain.handle('launch',async()=>{requireIdle();validate({version:settings.selected,...settings});busy=true;controller=new AbortController();status('preparing','检查本地版本与 Java');
  const game=engine({signal:controller.signal,onProgress:p=>{const mb=(p.speed/1024**2).toFixed(1);status('downloading',`文件 ${p.done}/${p.total} · 已复用 ${p.reused} · 下载 ${p.downloaded} · ${mb} MB/s`,p.total?p.done/p.total*100:0);}});
  try{log('游戏根目录：'+settings.root);log('版本隔离：'+(settings.isolate?'开启':'关闭')+' · 下载源：'+settings.source);child=await game.launch();controller=null;status('running','游戏正在运行',100);
    child.once('error',e=>{log(e.message);status('error',e.message);});child.once('close',async code=>{child=null;busy=false;status(code===0?'idle':'error',code===0?'游戏已退出':'游戏退出，代码 '+code);log('游戏退出，代码 '+code);send('instances-changed',await local());});return true;
  }catch(e){busy=false;child=null;controller=null;status('error',e.message);log(e.message);send('instances-changed',await local());throw e;}
});
