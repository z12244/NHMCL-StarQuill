const {app,BrowserWindow,ipcMain,dialog,shell,net,safeStorage}=require('electron');
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {Game,inspectJava}=require('./game.cjs');
const {layout,scan,writeJSON,migrateLegacy}=require('./storage.cjs');
const {validate,runtimePath,redact}=require('./core.cjs');
const {scanJava,chooseJava,requiredJava,memoryLimit}=require('./java.cjs');
const {AccountStore,MicrosoftAuth,validClient}=require('./accounts.cjs');
const {lookupSkin,previewSkin,startSkinServer}=require('./skins.cjs');
let accounts,accountError='',javaItems=[],javaScan,loginController,skinServer;
const fetcher=(...args)=>net.fetch(...args);
const auth=new MicrosoftAuth({fetcher});
let win,child,busy=false,controller,settings,logs=[],closing=false;
let state={phase:'idle',text:'准备就绪',percent:0};
const home=()=>app.getPath('userData');
const portable=()=>process.env.PORTABLE_EXECUTABLE_DIR||(app.isPackaged?path.dirname(process.execPath):__dirname);
const defaults=()=>({name:'Player',memory:Math.min(4,Math.max(1,Math.floor(os.totalmem()/1024**3/2))),java:'',javaMode:'auto',javaRoots:[],microsoftClientId:'',selected:'1.21.1',snapshots:false,root:path.join(portable(),'.minecraft'),isolate:true,source:'auto',concurrency:16});
const bundled=()=>runtimePath(process.resourcesPath,__dirname,app.isPackaged);
function send(event,data){if(win&&!win.isDestroyed())win.webContents.send(event,data);}
function status(phase,text,percent=0){state={phase,text,percent:Number.isFinite(percent)?Math.min(100,Math.max(0,percent)):0};send('state',state);}
function log(text){let clean=redact(text);for(const a of accounts?.accounts||[])for(const key of ['accessToken','refreshToken'])if(a.tokens?.[key])clean=clean.replaceAll(a.tokens[key],'[redacted]');const line='['+new Date().toLocaleTimeString('zh-CN')+'] '+clean;logs.push(line);if(logs.length>1000)logs.shift();send('log',line);}
async function persist(){await writeJSON(path.join(home(),'settings.json'),settings);}
async function local(){return scan(settings.root);}
function requireIdle(){if(busy||loginController)throw Error('请等待当前任务或微软登录结束后再修改设置或账号');}
function scanRuntimes(){if(!javaScan)javaScan=scanJava({bundled:bundled(),selected:settings.java,root:settings.root,extraRoots:settings.javaRoots||[]}).then(items=>{javaItems=items;send('java-list',items);return items;}).finally(()=>{javaScan=null;});return javaScan;}
async function accountView(){const data=accounts.public();for(const a of data.accounts){if(a.skin)a.preview=await previewSkin(settings.root,a.skin);}return data;}
async function changedAccounts(){const data=await accountView();send('accounts-changed',data);return data;}
function stopSkin(){skinServer?.close();skinServer=null;}
function engine(extra={}){return new Game({...settings,java:settings.java||bundled(),version:settings.selected,onLog:log,fetcher:(...args)=>net.fetch(...args),...extra});}
app.whenReady().then(async()=>{
  await fs.mkdir(home(),{recursive:true});settings=defaults();try{const saved=JSON.parse(await fs.readFile(path.join(home(),'settings.json'),'utf8'));settings={...settings,...saved,javaMode:saved.javaMode||(saved.java?'manual':'auto')};}catch{}
  settings.memory=Math.min(memoryLimit(),Math.max(1,Math.floor(Number(settings.memory)||4)));
  accounts=new AccountStore(path.join(home(),'accounts.json'),safeStorage);try{await accounts.load(settings.name);}catch(e){accountError=e.message;}
  win=new BrowserWindow({width:1260,height:850,minWidth:980,minHeight:720,backgroundColor:'#101915',title:'NHMCL-StarQuill · 星翎启动器',icon:path.join(__dirname,'assets','icon.png'),autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',e=>e.preventDefault());
  win.on('close',e=>{if(busy&&!closing){e.preventDefault();dialog.showMessageBox(win,{type:'question',message:'当前任务尚未结束，是否关闭？',detail:'下载将保留已完成文件与续传数据；运行中的游戏将结束。',buttons:['继续运行','关闭并结束任务'],defaultId:0,cancelId:0}).then(({response})=>{if(response===1){closing=true;controller?.abort();child?.kill();app.exit(0);}});}});
  win.on('focus',()=>{if(settings&&!busy)local().then(items=>send('instances-changed',items)).catch(()=>{});});
  await win.loadFile(path.join(__dirname,'index.html'));
  scanRuntimes().catch(e=>log(e.message));
});
app.on('before-quit',()=>{loginController?.abort();controller?.abort();stopSkin();});
app.on('window-all-closed',()=>app.quit());
ipcMain.handle('boot',async()=>({settings,instances:await local(),accounts:await accountView(),accountError,javaItems,totalMemory:memoryLimit(),physicalMemory:(os.totalmem()/1024**3).toFixed(1),state,version:app.getVersion()}));
ipcMain.handle('versions',async()=>engine().manifest());
ipcMain.handle('instances',()=>local());
ipcMain.handle('settings',async(_,o)=>{requireIdle();validate({version:o.selected||'1.21.1',name:accounts.current().name,memory:o.memory});
  if(typeof o.java!=='string'||o.java.length>1024)throw Error('Java 路径无效');
  if(typeof o.root!=='string'||!path.isAbsolute(o.root))throw Error('请选择有效的 .minecraft 根目录');
  if(!['auto','bmclapi','official'].includes(o.source))throw Error('下载源无效');
  if(!Number.isInteger(o.concurrency)||o.concurrency<1||o.concurrency>32)throw Error('下载并发须为 1–32');
  if(!['auto','manual'].includes(o.javaMode))throw Error('Java 模式无效');
  if(o.javaMode==='manual'&&!o.java)throw Error('手动模式下请选择 Java');
  if(o.microsoftClientId&&!validClient(o.microsoftClientId))throw Error('Client ID 应为应用注册提供的 UUID，不是密钥');
  await fs.mkdir(o.root,{recursive:true});await fs.access(o.root,require('node:fs').constants.W_OK);
  settings={...settings,name:accounts.current().name,memory:o.memory,java:o.java,javaMode:o.javaMode,microsoftClientId:o.microsoftClientId||'',selected:o.selected,snapshots:!!o.snapshots,root:path.resolve(o.root),isolate:o.isolate!==false,source:o.source,concurrency:o.concurrency};await persist();await changedAccounts();return {settings,instances:await local()};
});
ipcMain.handle('select-root',async()=>{requireIdle();const r=await dialog.showOpenDialog(win,{title:'选择已有 .minecraft 或启动器所在文件夹',defaultPath:settings.root,properties:['openDirectory','createDirectory']});if(r.canceled)return null;let root=r.filePaths[0];try{if((await fs.stat(path.join(root,'.minecraft'))).isDirectory())root=path.join(root,'.minecraft');}catch{}return {root,instances:await scan(root)};});
ipcMain.handle('migrate',async()=>{requireIdle();const r=await dialog.showOpenDialog(win,{title:'选择旧 Aster 的 instances 文件夹（复制导入，不删除原数据）',defaultPath:path.join(app.getPath('appData'),'aster-launcher','instances'),properties:['openDirectory']});if(r.canceled)return null;
  busy=true;status('preparing','正在复制旧版数据');try{const result=await migrateLegacy(r.filePaths[0],settings.root,text=>status('preparing',text));log(`迁移完成：${result.versions} 个版本，复制 ${result.copied} 个文件，跳过已有 ${result.skipped} 个文件`);if(result.conflicts.length)log('同名版本配置不同，未覆盖：'+result.conflicts.join('、'));send('instances-changed',await local());status('idle','迁移完成');return result;}catch(e){status('error',e.message);throw e;}finally{busy=false;}
});
ipcMain.handle('java',async()=>{const r=await dialog.showOpenDialog(win,{title:'选择 java.exe',properties:['openFile'],filters:[{name:'Java',extensions:['exe']}]});return r.canceled?null:inspectJava(r.filePaths[0]);});
ipcMain.handle('scan-java',()=>scanRuntimes());
ipcMain.handle('scan-java-folder',async()=>{requireIdle();const r=await dialog.showOpenDialog(win,{title:'选择 Java 所在文件夹（扫描最多 5 层子目录）',properties:['openDirectory']});if(r.canceled)return null;settings.javaRoots=[...new Set([...(settings.javaRoots||[]),r.filePaths[0]])].slice(-20);await persist();if(javaScan)await javaScan;return scanRuntimes();});
ipcMain.handle('account-add',async(_,name)=>{requireIdle();await accounts.addOffline(name);return changedAccounts();});
ipcMain.handle('account-select',async(_,id)=>{requireIdle();await accounts.select(id);return changedAccounts();});
ipcMain.handle('account-remove',async(_,id)=>{requireIdle();await accounts.remove(id);return changedAccounts();});
ipcMain.handle('account-skin',async(_,name)=>{requireIdle();const account=accounts.current();if(account.type!=='offline')throw Error('请先选择离线账号');busy=true;try{const skin=name?await lookupSkin(settings.root,name,fetcher):null;await accounts.put({...account,skin});return changedAccounts();}finally{busy=false;}});
ipcMain.handle('login-start',async()=>{requireIdle();if(!safeStorage.isEncryptionAvailable())throw Error('Windows 安全存储不可用，无法保存微软登录');
  const controller=new AbortController();loginController=controller;
  try{const device=await auth.begin(settings.microsoftClientId,controller.signal);
    auth.poll(device,controller.signal).then(async account=>{if(controller.signal.aborted)return;await accounts.put(account,true);await changedAccounts();send('login-state',{phase:'success',text:'微软正版账号已登录'});}).catch(e=>send('login-state',{phase:'error',text:e.message})).finally(()=>{if(loginController===controller)loginController=null;});
    return {userCode:device.user_code,url:device.verification_uri,expiresAt:device.expiresAt};
  }catch(e){loginController=null;throw e;}
});
ipcMain.handle('login-cancel',()=>{loginController?.abort();return true;});
ipcMain.handle('login-browser',()=>shell.openExternal('https://www.microsoft.com/link'));
ipcMain.handle('folder',async(_,id)=>{const p=id?layout(settings.root,id,settings.isolate).game:settings.root;await fs.mkdir(p,{recursive:true});const error=await shell.openPath(p);if(error)throw Error(error);});
ipcMain.handle('export-log',async()=>{const r=await dialog.showSaveDialog(win,{defaultPath:'NHMCL-StarQuill-log.txt',filters:[{name:'文本日志',extensions:['txt']}]});if(r.canceled)return false;await fs.writeFile(r.filePath,logs.join('\r\n'));return true;});
ipcMain.handle('stop',()=>{if(child){child.kill();return true;}if(controller){controller.abort();return true;}return false;});
ipcMain.handle('launch',async()=>{requireIdle();if(accountError)throw Error(accountError);validate({version:settings.selected,...settings,name:accounts.current().name});busy=true;controller=new AbortController();status('preparing','检查本地版本与 Java');
  const game=engine({signal:controller.signal,onProgress:p=>{const mb=(p.speed/1024**2).toFixed(1);status('downloading',`文件 ${p.done}/${p.total} · 已复用 ${p.reused} · 下载 ${p.downloaded} · ${mb} MB/s`,p.total?p.done/p.total*100:0);}});
  try{log('游戏根目录：'+settings.root);log('版本隔离：'+(settings.isolate?'开启':'关闭')+' · 下载源：'+settings.source);
    const resolved=await game.resolve(),required=requiredJava(resolved.meta);
    const java=settings.javaMode==='auto'?chooseJava(await scanRuntimes(),required,settings.memory):await inspectJava(settings.java);
    game.options.java=java.path;log(`${settings.javaMode==='auto'?'自动选择':'手动指定'} Java ${java.version} (${java.bits} 位)：${java.path}`);
    let account=accounts.current();if(account.type==='microsoft'){status('preparing','验证微软正版账号');account=await auth.refresh(account,controller.signal,a=>accounts.put(a));await accounts.put(account);await changedAccounts();}
    game.options.name=account.name;game.options.account=account;
    if(account.type==='offline'&&account.skin){skinServer=await startSkinServer(settings.root,account,path.join(app.isPackaged?process.resourcesPath:__dirname,'tools','authlib-injector-1.2.8.jar'),log);game.options.extraJvmArgs=skinServer.jvmArgs;log('使用离线皮肤：'+account.skin.sourceName+' · 玩家 UUID 保持不变');}
    child=await game.launch();controller=null;status('running','游戏正在运行',100);
    child.once('error',e=>{log(e.message);status('error',e.message);});child.once('close',async code=>{stopSkin();child=null;busy=false;status(code===0?'idle':'error',code===0?'游戏已退出':'游戏退出，代码 '+code);log('游戏退出，代码 '+code);send('instances-changed',await local());});return true;
  }catch(e){stopSkin();busy=false;child=null;controller=null;status('error',e.message);log(e.message);send('instances-changed',await local());throw e;}
});
