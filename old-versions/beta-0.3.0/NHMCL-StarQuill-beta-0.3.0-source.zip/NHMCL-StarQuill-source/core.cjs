const path=require('node:path');
function validate(o){if(!o)throw Error('请选择有效的游戏版本');require('./storage.cjs').versionName(o.version);if(!/^[a-zA-Z0-9_]{3,16}$/.test(o.name))throw Error('玩家名须为 3–16 位英文字母、数字或下划线');if(!Number.isInteger(o.memory)||o.memory<1||o.memory>32)throw Error('内存须为 1–32 GB');return o;}
function javaMajor(text){const m=text.match(/version\s+"(?:1\.)?(\d+)/i);return m?Number(m[1]):null;}
function runtimePath(resources,devRoot,packaged){return path.join(packaged?resources:devRoot,'runtime','bin','java.exe');}
function redact(text){return String(text).replace(/(--accessToken\s+)\S+/gi,'$1[redacted]').replace(/(Bearer\s+)\S+/gi,'$1[redacted]');}
module.exports={validate,javaMajor,runtimePath,redact};
