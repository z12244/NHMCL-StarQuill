const os = require('node:os');
const path = require('node:path');
const {execFile} = require('node:child_process');

function memorySnapshot(system = os) {
  const total = Math.max(0, system.totalmem());
  const available = Math.max(0, Math.min(total, system.freemem()));
  return {total, available, used: total - available, sampledAt: Date.now()};
}

// Only the launcher's own Electron processes are supplied by the main process.
// Trimming their working sets makes pages reclaimable; it does not create RAM.
function trimScript(pids) {
  const ids = [...new Set(pids.filter(id => Number.isSafeInteger(id) && id > 0))];
  if (!ids.length) throw Error('没有可优化的启动器进程');
  return `$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class StarQuillMemory {
  [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr OpenProcess(uint access, bool inherit, int id);
  [DllImport("psapi.dll", SetLastError=true)] public static extern bool EmptyWorkingSet(IntPtr process);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr handle);
}
'@
$done = 0
foreach ($targetId in @(${ids.join(',')})) {
  $handle = [StarQuillMemory]::OpenProcess(0x1100, $false, $targetId)
  if ($handle -ne [IntPtr]::Zero) {
    try { if ([StarQuillMemory]::EmptyWorkingSet($handle)) { $done++ } }
    finally { [void][StarQuillMemory]::CloseHandle($handle) }
  }
}
if ($done -eq 0) { throw 'No launcher working sets could be trimmed' }
Write-Output $done`;
}

async function optimizeMemory(pids, signal) {
  signal?.throwIfAborted();
  if (process.platform !== 'win32') return {supported: false, ...memorySnapshot()};
  const script = Buffer.from(trimScript(pids), 'utf16le').toString('base64');
  const powershell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  await new Promise((resolve, reject) => {
    execFile(powershell, ['-NoLogo', '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-EncodedCommand', script],
      {windowsHide: true, timeout: 10000, maxBuffer: 65536, signal}, error => error ? reject(error) : resolve());
  });
  return {supported: true, ...memorySnapshot()};
}
module.exports = {memorySnapshot, optimizeMemory, trimScript};
