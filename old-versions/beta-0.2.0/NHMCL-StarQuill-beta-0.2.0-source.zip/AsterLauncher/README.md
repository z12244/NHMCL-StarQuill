# Aster 星野启动器 0.2.0

Windows x64 桌面启动器开发预览。原创方块山谷界面，基于 Electron 和 minecraft-launcher-core。**尚未实现 HMCL、PCL、BakaXL 的全部非联机功能。**

## 使用

双击 `Aster-Launcher-0.2.0-win-x64.exe`。这是便携单文件版，启动时将程序解压到临时目录；首次打开可能稍慢，不要求安装 Node.js、npm 或系统 Java。

1. 默认选中 Minecraft 1.21.1，可直接使用内置 Java 21。
2. 在「启动设置」中设置离线玩家名和内存，点击保存。
3. 点击「启动游戏」，首次联网下载原版游戏、库和资源，下载过程中保持启动器打开。
4. 启动失败时查看「运行日志」，可以导出为文本。

程序包含 **Eclipse Temurin Java 21.0.13+9 JRE**，不是包含 javac 等开发工具的完整 JDK。运行 Minecraft 不需要 javac。其他游戏版本按官方版本配置检查 Java 主版本；需要 Java 8、17、25 等时，在设置中指定对应 java.exe。

游戏数据与设置保存在 `%APPDATA%/aster-launcher/`，便携 EXE 自身不包含个人存档。每个游戏版本独立目录；点击「我的版本」可打开文件夹或重新选中版本。不要在下载或游戏运行时移动、删除实例文件。

## 已实现

- 原创 Minecraft 风格像素山谷、草方块标志、四个中文功能页面。
- 官方版本列表、快照筛选、本地版本列表缓存与网络错误提示。
- 离线档案，原版游戏下载和启动、每版本目录隔离。
- 内置 Java 21、选择自定义 Java、启动前主版本核对。
- 内存设置与持久化、阶段下载进度、运行日志和导出、结束游戏。
- Windows x64 便携 EXE，无需开发环境；保留 Chromium 沙箱和隔离的 IPC。

## 当前限制

没有微软正版登录、第三方认证、加载器自动安装、模组/资源包搜索更新、整合包导入导出、自动 Java 多版本下载、自动更新或完整崩溃分析。离线档案不提供正版身份认证。没有联机辅助功能。

本机为 Windows 11，已经实际打开单文件 EXE、读取官方版本列表和保存设置。独立测试使用同一启动适配器及内置 Java 启动 Minecraft 1.21.1，完成声音、纹理和 GUI 图集初始化并创建游戏窗口；90 秒后由测试脚本结束。未测试创建世界和长时间游戏。Windows 10 x64 为目标系统，未在独立 Windows 10 设备上实测；不能承诺所有旧版 Minecraft 或所有硬件都兼容。构建没有商业代码签名证书。

## 源码构建

安装 Node.js 和 npm，进入源码目录：

```text
npm ci
npm start
npm test
npm run dist
```

源码压缩包不含 node_modules 和 Java 二进制。请从 Eclipse Adoptium 官方下载 Windows x64 Java 21 JRE，解压到 runtime，使 runtime/bin/java.exe 存在，保留完整许可证。源代码中的构建输出路径适用于当前目录布局，可按需调整 package.json 的 build.directories.output。

## 资料与许可证

- HMCL: https://github.com/HMCL-dev/HMCL
- PCL: https://github.com/Hex-Dragon/PCL2
- BakaXL: https://www.bakaxl.com/
- 启动库: https://github.com/Pierce01/MinecraftLauncher-core
- Electron: https://www.electronjs.org/
- Java: https://adoptium.net/

没有复制上述启动器的品牌或界面素材。第三方依赖声明见 THIRD-PARTY-NOTICES.txt；Java 原始许可随运行时保留，Electron/Chromium 原始许可随程序保留。
