# NHMCL-StarQuill · 星翎启动器 0.3.0

**以星为笔，启程方块世界！**

该启动器由 StarQuill_z12244 发起的 Minecraft 启动器项目。经由南湖模作社参与维护与发行。

## 使用与默认目录

双击 `NHMCL-StarQuill-0.3.0-win-x64.exe`。单文件版包含 Temurin Java 21 JRE，首次启动会解压程序，无需安装 Node.js 或 Java 21。游戏文件默认放在 **EXE 所在目录的 `.minecraft`**，不放在临时解压目录。

```text
NHMCL-StarQuill-0.3.0-win-x64.exe
.minecraft/
  assets/
    indexes/17.json              # 使用版本 JSON 中真实的资源索引 ID
    objects/ab/abcdef...         # 按内容哈希共享的资源
    log_configs/
  libraries/                    # 标准 Maven 目录，各版本共享
  versions/
    1.21.1/
      1.21.1.json
      1.21.1.jar
      saves/
      mods/
      config/
      resourcepacks/
      logs/
      natives/
  .starquill/                    # 本启动器的版本列表和校验缓存
```

`saves`、`mods` 等目录由游戏或模组按需创建，不会预先制造空文件。版本隔离默认开启：Java 的工作目录与 `--gameDir` 都是 `versions/版本名`。关闭隔离则使用 `.minecraft` 根目录中的存档和配置；切换隔离不会自动搬动存档。

启动器选项与所选根目录记录在系统应用数据目录（`%APPDATA%/nhmcl-starquill` 或产品名称对应目录），游戏文件均留在所选 `.minecraft`。Java 21 随 EXE 分发，不属于游戏下载目录。

## 直接使用 PCL / HMCL 下载的版本

1. 打开「启动设置」→「选择目录」。
2. 选择已有 `.minecraft`；也可选择其上一层文件夹，程序会识别其中的 `.minecraft`。
3. 保存设置。「我的版本」及首页的「本地版本」分组会列出现有版本。
4. 选择版本启动。已有 JSON、JAR、libraries 和 assets 会被复用，只补齐缺失或校验失败的文件。

请保留完整 `.minecraft`。仅复制 `versions/1.21.1` 不包含共享依赖和资源，会触发补全下载。中文和空格版本名、标准 `inheritsFrom` 父版本、Maven 依赖覆盖和通用 JVM/game 参数均可读取，不会将原版本 JSON 改写为私有格式。

本次验证覆盖原版 1.21.1 和合成的继承式加载器配置。读取通用目录不等于已验证所有 Forge、NeoForge、Fabric、OptiFine 历史组合；加载器的安装产物仍需完整，旧游戏可能需要自行选择 Java 8 / 17 等运行时。

## 导入旧版 Aster 数据

在设置中点击「导入旧 Aster 数据」，选择旧的 `instances` 文件夹。旧版默认位置是 `%APPDATA%/aster-launcher/instances`。

程序把每个旧实例的公共 assets / libraries 合并到新根目录，版本 JSON / JAR 放入 versions，并将存档、mods、配置复制到对应版本目录。**只复制，不删除原数据，不覆盖已有文件**；同名但配置不同的版本会跳过并记入日志。迁移前需选好目标 `.minecraft` 并保存。

## 下载设置

- **自动（默认）**：BMCLAPI 国内镜像优先，失败回退官方；镜像连续连接失败后暂时使用官方源。
- **BMCLAPI**：优先国内镜像，官方兜底。
- **仅官方源**：不经过镜像。
- 默认 16 个并行任务，可调 1–32。使用有界队列，避免同时开启数千个下载。
- 版本元数据、游戏 JAR、资源和依赖库按来源规则切换。未映射的第三方 Maven 地址保持原来源。
- 使用系统网络栈，保留 TLS 证书验证；对有官方哈希/长度的文件校验完整性。
- `.starquill.part` 临时文件支持 HTTP Range 续传；服务器不支持 Range 时重新下载当前文件。通过校验后才发布正式文件。
- 点击「取消下载」保留已完成文件和续传数据。重新启动继续检查与补全。
- 已校验文件保存大小、修改时间和哈希记录；再次启动优先复用。改变的文件会重新校验。

镜像速度取决于当前节点与网络，不保证每次快于官方。速度异常时可在设置中切换来源。日志会记录回退与文件复用数量。

## 开发和构建

```text
npm ci
npm test
npm start
npm run dist
```

源码包不含 Java 二进制或 node_modules。将 Windows x64 Temurin Java 21 JRE 解压到 `runtime/`，确保 `runtime/bin/java.exe` 存在，并保留原始许可证。

这一版重写了存储、版本解析、下载和启动参数生成模块，已移除 minecraft-launcher-core 依赖。运行依赖仅保留 adm-zip 用于旧版本原生库解压。单文件 EXE 未做商业代码签名。

## 参考与声明

- HMCL 版本隔离文档：https://docs.hmcl.net/launcher/isolation.html
- BMCLAPI 文档：https://bmclapidoc.bangbang93.com/
- Java：https://adoptium.net/

项目采用通用 Minecraft 文件约定，没有复制 HMCL/PCL 品牌或源代码。BMCLAPI 提供国内镜像服务。不是 Mojang / Microsoft 官方产品。第三方声明见 `THIRD-PARTY-NOTICES.txt`。
