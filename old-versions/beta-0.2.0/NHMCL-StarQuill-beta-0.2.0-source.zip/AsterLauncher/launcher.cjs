// Keep process execution shell-free, including the core library's Java probe.
const {Client,Authenticator}=require('minecraft-launcher-core');
const Handler=require('minecraft-launcher-core/components/handler');
const {spawn,execFile}=require('node:child_process');
Handler.prototype.checkJava=function(java){return new Promise(resolve=>execFile(java,['-version'],{windowsHide:true,timeout:12000},error=>resolve({run:!error,message:error?.message})));};
class Launcher extends Client{
startMinecraft(args){const game=spawn(this.options.javaPath||'java',args,{cwd:this.options.root,detached:false,windowsHide:true});game.stdout.on('data',data=>this.emit('data',data.toString()));game.stderr.on('data',data=>this.emit('data',data.toString()));game.on('close',code=>this.emit('close',code));return game;}
}
module.exports={Client:Launcher,Authenticator};
