const {app,BrowserWindow,ipcMain,dialog,shell}=require('electron');
const {Client,Authenticator}=require('./launcher.cjs');
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {execFile}=require('node:child_process'),{promisify}=require('node:util');
const {validate,javaMajor,runtimePath,redact}=require('./core.cjs');
const exec=promisify(execFile),smoke=process.argv.includes('--smoke-test');
if(smoke)app.setPath('userData',path.join(os.tmpdir(),'aster-smoke-test'));
let win,child,busy=false,manifest=[],settings={},logBuffer=[],state={phase:'idle',text:'准备就绪',percent:0},closing=false;
const home=()=>app.getPath('userData'),base=()=>path.join(home(),'instances');
const defaults={name:'Player',memory:Math.min(4,Math.max(1,Math.floor(os.totalmem()/1024**3/2))),java:'',selected:'1.21.1',snapshots:false};
const bundled=()=>runtimePath(process.resourcesPath,__dirname,app.isPackaged);
async function json(url){const r=await fetch(url,{signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error('请求失败：HTTP '+r.status);return r.json();}
function send(event,data){if(win&&!win.isDestroyed())win.webContents.send(event,data);}
function status(phase,text,percent=0){state={phase,text,percent:Number.isFinite(percent)?Math.min(100,Math.max(0,percent)):0};send('state',state);}
function log(t){const line='['+new Date().toLocaleTimeString('zh-CN')+'] '+redact(t);logBuffer.push(line);if(logBuffer.length>800)logBuffer.shift();send('log',line);}
async function persist(){await fs.writeFile(path.join(home(),'settings.json'),JSON.stringify(settings,null,2));}
async function instances(){await fs.mkdir(base(),{recursive:true});const dirs=await fs.readdir(base(),{withFileTypes:true});const result=[];for(const d of dirs.filter(d=>d.isDirectory())){let ready=false;try{await fs.access(path.join(base(),d.name,'versions',d.name,d.name+'.json'));ready=true;}catch{}result.push({id:d.name,ready});}return result;}
function instance(id){validate({version:id,name:'Player',memory:1});return path.join(base(),id);}
async function inspectJava(file){try{const {stdout,stderr}=await exec(file,['-version'],{windowsHide:true,timeout:12000});const text=stdout+stderr;return {path:file,major:javaMajor(text),description:text.split('\n')[0]};}catch{throw Error('Java 无法运行，请选择有效的 java.exe');}}
app.whenReady().then(async()=>{await fs.mkdir(home(),{recursive:true});try{settings={...defaults,...JSON.parse(await fs.readFile(path.join(home(),'settings.json'),'utf8'))};}catch{settings={...defaults};}
win=new BrowserWindow({width:1260,height:850,minWidth:980,minHeight:720,show:!smoke,backgroundColor:'#101915',title:'Aster 星野启动器',icon:path.join(__dirname,'assets','icon.png'),autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',e=>e.preventDefault());
win.on('close',e=>{if(busy&&!closing){e.preventDefault();dialog.showMessageBox(win,{type:'question',message:'任务仍在运行，关闭启动器？',detail:'关闭启动器会中断下载或结束由它启动的游戏。',buttons:['继续运行','关闭并结束任务'],defaultId:0,cancelId:0}).then(({response})=>{if(response===1){closing=true;child?.kill();app.exit(0);}});}});
await win.loadFile('index.html');
if(smoke){try{await win.webContents.executeJavaScript('window.asterReady');await new Promise(r=>setTimeout(r,800));const report=await win.webContents.executeJavaScript(`({title:document.title,bridge:!!window.aster,errors:window.bootError||null,buttons:document.querySelectorAll('button').length,overflow:document.documentElement.scrollWidth>innerWidth})`);report.java=await inspectJava(bundled());report.packaged=app.isPackaged;const out=process.env.ASTER_TEST_OUTPUT||home();await fs.mkdir(out,{recursive:true});await fs.writeFile(path.join(out,'smoke-test.json'),JSON.stringify(report,null,2));await fs.writeFile(path.join(out,'launcher-preview.png'),(await win.webContents.capturePage()).toPNG());app.exit(report.errors||report.overflow?1:0);}catch(e){console.error(e);app.exit(1);}}
});
app.on('window-all-closed',()=>app.quit());
ipcMain.handle('boot',async()=>({settings,instances:await instances(),bundledJava:await inspectJava(bundled()).catch(()=>null),totalMemory:Math.round(os.totalmem()/1024**3),state,version:app.getVersion()}));
ipcMain.handle('versions',async()=>{try{const data=await json('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');manifest=data.versions;await fs.writeFile(path.join(home(),'manifest.json'),JSON.stringify(data));return {versions:manifest,cached:false};}catch(e){try{manifest=JSON.parse(await fs.readFile(path.join(home(),'manifest.json'),'utf8')).versions;return {versions:manifest,cached:true};}catch{throw Error('无法连接官方版本服务，请检查网络后重试。');}}});
ipcMain.handle('settings',async(_,o)=>{validate({version:o.selected||'1.21.1',name:o.name,memory:o.memory});if(typeof o.java!=='string'||o.java.length>1024)throw Error('Java 路径无效');settings={name:o.name,memory:o.memory,java:o.java,selected:o.selected,snapshots:!!o.snapshots};await persist();return settings;});
ipcMain.handle('java',async()=>{const r=await dialog.showOpenDialog(win,{title:'选择 java.exe',properties:['openFile'],filters:[{name:'Java',extensions:['exe']}]});if(r.canceled)return null;return inspectJava(r.filePaths[0]);});
ipcMain.handle('folder',async(_,id)=>{const p=id?instance(id):base();await fs.mkdir(p,{recursive:true});const error=await shell.openPath(p);if(error)throw Error(error);});
ipcMain.handle('instances',()=>instances());
ipcMain.handle('export-log',async()=>{const r=await dialog.showSaveDialog(win,{defaultPath:'aster-log.txt',filters:[{name:'文本日志',extensions:['txt']}]});if(!r.canceled){await fs.writeFile(r.filePath,logBuffer.join('\r\n'));return true;}return false;});
ipcMain.handle('stop',()=>{if(child){child.kill();log('已请求结束游戏');return true;}return false;});
ipcMain.handle('launch',async(_,o)=>{if(busy)throw Error('已有任务正在运行');validate(o);busy=true;status('preparing','检查 Java 与版本配置');try{
const root=instance(o.version);await fs.mkdir(root,{recursive:true});let meta;const entry=manifest.find(v=>v.id===o.version);try{if(entry)meta=await json(entry.url);else meta=JSON.parse(await fs.readFile(path.join(root,'versions',o.version,o.version+'.json'),'utf8'));}catch{throw Error('无法读取版本配置，请刷新版本列表并检查网络');}
const java=await inspectJava(o.java||bundled());const required=meta.javaVersion?.majorVersion||8;
if(java.major!==required)throw Error('此版本需要 Java '+required+'，当前为 Java '+java.major+'。请在设置中选择 Java '+required+' 的 java.exe。');
settings={...settings,name:o.name,memory:o.memory,java:o.java,selected:o.version};await persist();
log('启动 '+o.version+' · Java '+java.major+' · 最大内存 '+o.memory+' GB');status('downloading','下载并校验游戏资源');
const client=new Client();client.on('data',log);client.on('debug',log);client.on('progress',p=>{status('downloading','准备资源 · '+p.type,p.total?p.task/p.total*100:0);});client.on('download-status',p=>{status('downloading','正在下载游戏文件',p.total?p.current/p.total*100:0);});
child=await client.launch({authorization:Authenticator.getAuth(o.name),root,version:{number:o.version,type:meta.type||'release'},javaPath:java.path,memory:{min:'512M',max:o.memory+'G'}});
if(!child)throw Error('游戏进程未创建，请查看运行日志');status('running','游戏正在运行',100);log('游戏进程已创建');
child.once('close',code=>{busy=false;child=null;status(code===0?'idle':'error',code===0?'游戏已退出':'游戏退出，代码 '+code);log('游戏退出，代码 '+code);send('instances-changed',null);});child.once('error',e=>log(e.message));return true;
}catch(e){busy=false;child=null;status('error',e.message);log(e.message);throw e;}});
